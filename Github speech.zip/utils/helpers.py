import numpy as np
import librosa
import plotly.graph_objects as go
from scipy import signal
import warnings
warnings.filterwarnings('ignore')

def load_audio(file_path: str, sr: int = None):
    """Load audio file"""
    audio, sample_rate = librosa.load(file_path, sr=sr)
    return audio, sample_rate

def save_audio(audio: np.ndarray, sample_rate: int, file_path: str):
    """Save audio to file"""
    import soundfile as sf
    sf.write(file_path, audio, sample_rate)

def compute_metrics(original: np.ndarray, processed: np.ndarray) -> tuple:
    """
    Compute audio quality metrics.
    
    Returns:
        (SNR, SDR)
    """
    # Signal-to-Noise Ratio
    noise = original - processed
    snr = 10 * np.log10(np.mean(processed ** 2) / (np.mean(noise ** 2) + 1e-10))
    
    # Source-to-Distortion Ratio (simplified)
    s_target = processed
    e_noise = original - processed
    sdr = 10 * np.log10(np.mean(s_target ** 2) / (np.mean(e_noise ** 2) + 1e-10))
    
    return snr, sdr

def detect_silence(audio: np.ndarray, sample_rate: int, threshold_db: float = -40) -> np.ndarray:
    """
    Detect silent frames in audio.
    
    Returns:
        Binary array (1 = silence, 0 = speech)
    """
    # Compute frame energy
    frame_length = int(0.02 * sample_rate)  # 20ms frames
    frames = librosa.util.frame(audio, frame_length=frame_length, hop_length=frame_length // 2)
    energy = np.sqrt(np.mean(frames ** 2, axis=0))
    
    # Convert to dB
    energy_db = 20 * np.log10(energy + 1e-10)
    
    # Threshold
    threshold = np.max(energy_db) + threshold_db
    silence_mask = energy_db < threshold
    
    return silence_mask

def detect_overlap(audio1: np.ndarray, audio2: np.ndarray, threshold: float = 0.3) -> bool:
    """
    Detect if two audio signals overlap significantly.
    
    Returns:
        True if overlap detected
    """
    # Compute correlation
    min_len = min(len(audio1), len(audio2))
    correlation = np.correlate(audio1[:min_len], audio2[:min_len], mode='valid')
    max_correlation = np.max(np.abs(correlation)) / (np.sqrt(np.sum(audio1 ** 2)) * np.sqrt(np.sum(audio2 ** 2)) + 1e-10)
    
    return max_correlation > threshold

class create_visualizations:
    @staticmethod
    def plot_waveform(audio: np.ndarray, sample_rate: int) -> go.Figure:
        """Create waveform plot"""
        time = np.arange(len(audio)) / sample_rate
        
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=time,
            y=audio,
            mode='lines',
            name='Waveform',
            line=dict(color='#667eea', width=1)
        ))
        
        fig.update_layout(
            title='Audio Waveform',
            xaxis_title='Time (s)',
            yaxis_title='Amplitude',
            hovermode='x unified',
            template='plotly_white'
        )
        
        return fig
    
    @staticmethod
    def plot_spectrogram(audio: np.ndarray, sample_rate: int) -> go.Figure:
        """Create spectrogram plot"""
        D = librosa.stft(audio)
        S_db = librosa.power_to_db(np.abs(D) ** 2, ref=np.max)
        
        fig = go.Figure(data=go.Heatmap(
            z=S_db,
            colorscale='Viridis',
            colorbar=dict(title='Power (dB)')
        ))
        
        fig.update_layout(
            title='Spectrogram',
            xaxis_title='Time',
            yaxis_title='Frequency',
            template='plotly_white'
        )
        
        return fig
    
    @staticmethod
    def plot_comparison(audio1: np.ndarray, audio2: np.ndarray, sample_rate: int, label1: str, label2: str) -> go.Figure:
        """Create comparison plot"""
        time = np.arange(len(audio1)) / sample_rate
        
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=time,
            y=audio1,
            mode='lines',
            name=label1,
            line=dict(color='#667eea')
        ))
        fig.add_trace(go.Scatter(
            x=time,
            y=audio2,
            mode='lines',
            name=label2,
            line=dict(color='#764ba2')
        ))
        
        fig.update_layout(
            title='Audio Comparison',
            xaxis_title='Time (s)',
            yaxis_title='Amplitude',
            hovermode='x unified',
            template='plotly_white'
        )
        
        return fig